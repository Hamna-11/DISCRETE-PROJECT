#include "PeopleManager.h"
#include "DisplayHelper.h"

using namespace std;

PeopleManager::Student::Student() : id(-1) {}
PeopleManager::Student::Student(int i, string n) : id(i), name(n) {}

PeopleManager::Faculty::Faculty() : id(-1) {}
PeopleManager::Faculty::Faculty(int i, string n) : id(i), name(n) {}

PeopleManager::Room::Room() : id(-1), capacity(30) {}
PeopleManager::Room::Room(int i, string n, int cap) : id(i), name(n), capacity(cap) {}

int PeopleManager::addStudent(const string& name) {
    int id = students.size();
    students.push_back(Student(id, name));
    DisplayHelper::printSuccess("Added student: " + name);
    return id;
}

int PeopleManager::addFaculty(const string& name) {
    int id = faculties.size();
    faculties.push_back(Faculty(id, name));
    DisplayHelper::printSuccess("Added faculty: " + name);
    return id;
}

int PeopleManager::addRoom(const string& name, int capacity) {
    int id = rooms.size();
    rooms.push_back(Room(id, name, capacity));
    DisplayHelper::printSuccess("Added room: " + name);
    return id;
}

PeopleManager::Student* PeopleManager::getStudent(int id) {
    if (id < 0 || id >= (int)students.size()) return nullptr;
    return &students[id];
}

PeopleManager::Faculty* PeopleManager::getFaculty(int id) {
    if (id < 0 || id >= (int)faculties.size()) return nullptr;
    return &faculties[id];
}

PeopleManager::Room* PeopleManager::getRoom(int id) {
    if (id < 0 || id >= (int)rooms.size()) return nullptr;
    return &rooms[id];
}

int PeopleManager::getStudentCount() const { 
    return students.size(); 
}

int PeopleManager::getFacultyCount() const { 
    return faculties.size(); 
}

int PeopleManager::getRoomCount() const { 
    return rooms.size(); 
}